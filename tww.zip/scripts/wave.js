const siren = Vars.tree.loadSound("airraid-siren");

Events.on(WaveEvent, e => {
    if(siren){
        
        siren.play(1.0, 1.0, 0); 
    }
});
