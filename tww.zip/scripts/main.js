require("wave"); 

const deathSounds = [
    Vars.tree.loadSound("d1"),
    Vars.tree.loadSound("d2"),
    Vars.tree.loadSound("d3")
];

const infantrySet = new Set([
    "b1", "b2", "c1", "c2", "d", "z1", "z2", "z3", "p", "s1", "s2",  
    "p1", "p2", "p3", "s", "g1", "g2", "k1", "k2", "l", "m", "n", 
    "o", "q1", "q2", "y", "r"
]);

const soundVolume = 1.2;
const soundPitchRange = { min: 0.9, max: 1.1 };

Events.on(UnitDestroyEvent, e => {
    const unit = e.unit;
    if (unit.type && infantrySet.has(unit.type.name)) {
        if (Math.random() < 0.5) {
            const sound = deathSounds[Math.floor(Math.random() * deathSounds.length)];
            
            const pitch = Math.random() * (soundPitchRange.max - soundPitchRange.min) + soundPitchRange.min;
            
            sound.at(unit.x, unit.y, soundVolume, pitch);
        }
    }
});

Events.on(ShootEvent, e => {
    
    if(e.source.block && e.source.block.name === "nuclear-weapon"){
        Fx.massiveExplosion.at(e.source.x, e.source.y);
        
        e.source.tile.setNet(Blocks.air); 
    }
});
